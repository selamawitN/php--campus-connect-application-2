Add department folder
